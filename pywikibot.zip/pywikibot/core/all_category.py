import os

from SPARQLWrapper import SPARQLWrapper, JSON
from flask import Flask, request, jsonify
from flask_cors import CORS

import sys
import pywikibot
import json
import pywikibot

app = Flask(__name__)
CORS(app)

endpoint_url = "https://query.wikidata.org/sparql"

#Kueri untuk makanan tradisional
@app.route('/culturenesian_makanan')
def get_result():
    query = """SELECT DISTINCT ?makanan ?makananLabel ?makananDescription ?makananAltLabel WHERE {
    SERVICE wikibase:label { bd:serviceParam wikibase:language "id, en, fr, es". }
    ?makanan (wdt:P31/(wdt:P279*)) wd:Q2095.
    ?makanan wdt:P17 wd:Q252.
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    data_dict = []

    for item in data["bindings"]:
        data_dict.append({
            "id": item["makanan"]["value"], 
            "value": item["makananLabel"]["value"], 
            "label": item["makananLabel"]["value"] if "makananLabel" in item else "",
            "description": item["makananDescription"]["value"] if "makananDescription" in item else "",
            "altLabel": item["makananAltLabel"]["value"] if "makananAltLabel" in item else ""
            })

    return json.dumps(data_dict)




#Kueri untuk rumah
@app.route('/culturenesian_rumah')
def get_rumah():
    query = """SELECT ?rumah ?rumahLabel ?rumahDescription ?rumahAltLabel WHERE {
    SERVICE wikibase:label { bd:serviceParam wikibase:language "[AUTO_LANGUAGE], id". }
    
    ?rumah wdt:P31 wd:Q7419654.

    ?rumah wdt:P17 wd:Q252.
    }"""    
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    data_dict = []
    for item in data["bindings"]:
        data_dict.append({"id": item["rumah"]["value"], "value": item["rumahLabel"]["value"]})
    return json.dumps(data_dict)



#Kueri untuk senjata
@app.route('/culturenesian_senjata')
def get_senjata():
    query = """SELECT DISTINCT ?senjata ?senjataLabel ?senjataDescription ?senjataAltLabel WHERE {
    SERVICE wikibase:label { bd:serviceParam wikibase:language "id, en, fr, es". }
    ?senjata (wdt:P31/(wdt:P279*)) wd:Q728.
    ?senjata wdt:P17 wd:Q252.
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    data_dict = []
    for item in data["bindings"]:
        data_dict.append({"id": item["senjata"]["value"], "value": item["senjataLabel"]["value"]})
    return json.dumps(data_dict)



#Kueri untuk lagu
@app.route('/culturenesian_lagu')
def get_lagu():
    query = """SELECT DISTINCT ?lagu ?laguLabel ?laguDescription ?laguAltLabel WHERE {
    SERVICE wikibase:label { bd:serviceParam wikibase:language "id, en, fr, es". }
    ?lagu wdt:P31 wd:Q105543609.
    ?lagu wdt:P7937 wd:Q7366.
    ?lagu wdt:P17 wd:Q252.
    }""" 
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    data_dict = []
    for item in data["bindings"]:
        data_dict.append({"id": item["lagu"]["value"], "value": item["laguLabel"]["value"]})
    return json.dumps(data_dict)



#Kueri untuk lagu
@app.route('/culturenesian_upacara')
def get_upacara():
    query = """SELECT DISTINCT ?upacara ?upacaraLabel ?upacaraDescription ?upacaraAltLabel WHERE {
    SERVICE wikibase:label { bd:serviceParam wikibase:language "id, en, fr, es". }
    ?upacara wdt:P31 wd:Q189819.
    ?upacara wdt:P17 wd:Q252.
    }""" 
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    data_dict = []
    for item in data["bindings"]:
        data_dict.append({"id": item["upacara"]["value"], "value": item["upacaraLabel"]["value"]})
    return json.dumps(data_dict)




#Kueri untuk tarian
@app.route('/culturenesian_tarian')
def get_tarian():
    query = """SELECT DISTINCT ?tarian ?tarianLabel ?tarianDescription ?tarianAltLabel WHERE {
    SERVICE wikibase:label { bd:serviceParam wikibase:language "id". }
    {?tarian wdt:P31 wd:Q107357104}
    UNION
    {?tarian wdt:P31 wd:Q105543609}
    ?tarian wdt:P17 wd:Q252
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    data_dict = []
    for item in data["bindings"]:
        data_dict.append({"id": item["tarian"]["value"], "value": item["tarianLabel"]["value"]})
    return json.dumps(data_dict)




# edit function
@app.route('/api/edit/<id>', methods=['GET', 'POST'])
def add_message(id):    
    site = pywikibot.Site("wikidata", "wikidata")
    repo = site.data_repository()
    item = pywikibot.ItemPage(repo, id)
            
    if item.exists():
        if request.method == 'GET':
            responseItem = item.get()
                            
            return jsonify({
                'code' : 200,
                'status' : 'ok',
                'message' : 'Success get data with code = ' + id,
                'data' : {
                    'label' : responseItem['labels'].toJSON(),
                    'description' : responseItem['descriptions'].toJSON(),
                    'aliases' : responseItem['aliases'].toJSON(),
                }
            })
        else:
            content = request.json            

            item.editLabels(content['label'], summary='edit label')
            item.editDescriptions(content['description'], summary='edit description')
            item.editAliases(content['aliases'], summary='edit aliases')        
            return jsonify({
                'code'  : 200,
                'status': 'ok',
                'message': 'Success update data with code = ' + id
                })
    else:
        return jsonify({
            'code'  : 400,
            'status': 'ok',
            'message': 'Data not found with code = ' + id
        })

@app.route('/bar/food', methods=['GET'])
def get_food():
    query = """SELECT DISTINCT (COUNT(*) AS ?count)
    WHERE {
    ?makanan (wdt:P31/(wdt:P279*)) wd:Q2095 .
    ?makanan wdt:P17 wd:Q252.
    ?makanan rdfs:label ?makananLabel
    FILTER(LANG(?makananLabel) = "id") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]

    # create dictionary with id and value
    data_dict = {}
    for item in data["bindings"]:
        data_dict["label_id"]= item["count"]["value"]

# MAKANAN LABEL EN
    query = """SELECT DISTINCT (COUNT(*) AS ?count)
    WHERE {
    ?makanan (wdt:P31/(wdt:P279*)) wd:Q2095 .
    ?makanan wdt:P17 wd:Q252.
    ?makanan rdfs:label ?makananLabel
    FILTER(LANG(?makananLabel) = "en") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    for item in data["bindings"]:
        data_dict["label_en"]= item["count"]["value"]
    
# MAKANAN LABEL ES
    query = """SELECT DISTINCT (COUNT(*) AS ?count)
    WHERE {
    ?makanan (wdt:P31/(wdt:P279*)) wd:Q2095 .
    ?makanan wdt:P17 wd:Q252.
    ?makanan rdfs:label ?makananLabel
    FILTER(LANG(?makananLabel) = "es") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    for item in data["bindings"]:
        data_dict["label_es"]= item["count"]["value"]


# MAKANAN LABEL FR  
    query = """SELECT DISTINCT (COUNT(*) AS ?count)
    WHERE {
    ?makanan (wdt:P31/(wdt:P279*)) wd:Q2095 .
    ?makanan wdt:P17 wd:Q252.
    ?makanan rdfs:label ?makananLabel
    FILTER(LANG(?makananLabel) = "fr") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    for item in data["bindings"]:
        data_dict["label_fr"]= item["count"]["value"]

# MAKANAN DESKRISI ID
    query = """SELECT DISTINCT (COUNT(*) AS ?count)
    WHERE {
    ?makanan (wdt:P31/(wdt:P279*)) wd:Q2095 .
    ?makanan wdt:P17 wd:Q252.
    ?makanan schema:description ?makananDescription 
    FILTER(LANG(?makananDescription) = "id") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]    
    for item in data["bindings"]:
        data_dict["desc_id"]= item["count"]["value"]


# MAKANAN DESKRIPSI EN
    query = """SELECT DISTINCT (COUNT(*) AS ?count)
    WHERE {
    ?makanan (wdt:P31/(wdt:P279*)) wd:Q2095 .
    ?makanan wdt:P17 wd:Q252.
    ?makanan schema:description ?makananDescription 
    FILTER(LANG(?makananDescription) = "en") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    for item in data["bindings"]:
        data_dict["desc_en"]= item["count"]["value"]

    
# MAKANAN DESKRIPSI ES
    query = """SELECT DISTINCT (COUNT(*) AS ?count)
    WHERE {
    ?makanan (wdt:P31/(wdt:P279*)) wd:Q2095 .
    ?makanan wdt:P17 wd:Q252.
    ?makanan schema:description ?makananDescription 
    FILTER(LANG(?makananDescription) = "es") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    for item in data["bindings"]:
        data_dict["desc_es"]= item["count"]["value"]


# MAKANAN DESKRIPSI FR
    query = """SELECT DISTINCT (COUNT(*) AS ?count)
    WHERE {
    ?makanan (wdt:P31/(wdt:P279*)) wd:Q2095 .
    ?makanan wdt:P17 wd:Q252.
    ?makanan schema:description ?makananDescription 
    FILTER(LANG(?makananDescription) = "fr") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    for item in data["bindings"]:
        data_dict["desc_fr"]= item["count"]["value"]


# MAKANAN ALIAS ID
    query = """SELECT DISTINCT (count(DISTINCT ?makanan) as ?count)
    WHERE {
    ?makanan (wdt:P31/(wdt:P279*)) wd:Q2095.
    ?makanan wdt:P17 wd:Q252.
    ?makanan skos:altLabel ?AltLabel .
    FILTER(lang(?AltLabel)="id")
    } GROUP BY ?makananAltLabel"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value    
    for item in data["bindings"]:
        data_dict["aliases_id"]= item["count"]["value"]

# MAKANAN ALIAS EN
    query = """SELECT DISTINCT (count(DISTINCT ?makanan) as ?count)
    WHERE {
    ?makanan (wdt:P31/(wdt:P279*)) wd:Q2095.
    ?makanan wdt:P17 wd:Q252.
    ?makanan skos:altLabel ?AltLabel .
    FILTER(lang(?AltLabel)="en")
    } GROUP BY ?makananAltLabel"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    for item in data["bindings"]:
        data_dict["aliases_en"]= item["count"]["value"]

    
# MAKANAN ALIAS ES
    query = """SELECT DISTINCT (count(DISTINCT ?makanan) as ?count)
    WHERE {
    ?makanan (wdt:P31/(wdt:P279*)) wd:Q2095.
    ?makanan wdt:P17 wd:Q252.
    ?makanan skos:altLabel ?AltLabel .
    FILTER(lang(?AltLabel)="es")
    } GROUP BY ?makananAltLabel"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    for item in data["bindings"]:
        data_dict["aliases_es"]= item["count"]["value"]

# MAKANAN ALIAS FR
    query = """SELECT DISTINCT (count(DISTINCT ?makanan) as ?count)
    WHERE {
    ?makanan (wdt:P31/(wdt:P279*)) wd:Q2095.
    ?makanan wdt:P17 wd:Q252.
    ?makanan skos:altLabel ?AltLabel .
    FILTER(lang(?AltLabel)="fr")
    } GROUP BY ?makananAltLabel"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    for item in data["bindings"]:
        data_dict["aliases_fr"]= item["count"]["value"]

    return json.dumps(data_dict)

@app.route('/bar/dance', methods=['GET'])
def get_dance():  
    query = """SELECT DISTINCT (COUNT(*) AS ?count) WHERE {
    {?tarian wdt:P31 wd:Q107357104}
    UNION
    {?tarian wdt:P31 wd:Q105543609}
    ?tarian wdt:P17 wd:Q252 .
    ?tarian rdfs:label ?tarianLabel
    FILTER(LANG(?tarianLabel) = "id") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    data_dict = {}
    for item in data["bindings"]:
        data_dict["label_id"]= item["count"]["value"]

# TARIAN EN
    query = """SELECT DISTINCT (COUNT(*) AS ?count) WHERE {
    {?tarian wdt:P31 wd:Q107357104}
    UNION
    {?tarian wdt:P31 wd:Q105543609}
    ?tarian wdt:P17 wd:Q252 .
    ?tarian rdfs:label ?tarianLabel
    FILTER(LANG(?tarianLabel) = "en") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    for item in data["bindings"]:
        data_dict["label_en"]= item["count"]["value"]
    
# TARIAN ES
    query = """SELECT DISTINCT (COUNT(*) AS ?count) WHERE {
    {?tarian wdt:P31 wd:Q107357104}
    UNION
    {?tarian wdt:P31 wd:Q105543609}
    ?tarian wdt:P17 wd:Q252 .
    ?tarian rdfs:label ?tarianLabel
    FILTER(LANG(?tarianLabel) = "es") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    for item in data["bindings"]:
        data_dict["label_es"]= item["count"]["value"]


# TARIAN FR  
    query = """SELECT DISTINCT (COUNT(*) AS ?count) WHERE {
    {?tarian wdt:P31 wd:Q107357104}
    UNION
    {?tarian wdt:P31 wd:Q105543609}
    ?tarian wdt:P17 wd:Q252 .
    ?tarian rdfs:label ?tarianLabel
    FILTER(LANG(?tarianLabel) = "fr") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    for item in data["bindings"]:
        data_dict["label_fr"]= item["count"]["value"]

    query = """SELECT DISTINCT (COUNT(*) AS ?count) WHERE {
    {?tarian wdt:P31 wd:Q107357104}
    UNION
    {?tarian wdt:P31 wd:Q105543609}
    ?tarian wdt:P17 wd:Q252 .
    ?tarian schema:description ?tarianDescription FILTER(LANG(?tarianDescription) = "id") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value    
    for item in data["bindings"]:
        data_dict["desc_id"]= item["count"]["value"]


    query = """SELECT DISTINCT (COUNT(*) AS ?count) WHERE {
    {?tarian wdt:P31 wd:Q107357104}
    UNION
    {?tarian wdt:P31 wd:Q105543609}
    ?tarian wdt:P17 wd:Q252 .
    ?tarian schema:description ?tarianDescription FILTER(LANG(?tarianDescription) = "en") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    for item in data["bindings"]:
        data_dict["desc_en"]= item["count"]["value"]

    

    query = """SELECT DISTINCT (COUNT(*) AS ?count) WHERE {
    {?tarian wdt:P31 wd:Q107357104}
    UNION
    {?tarian wdt:P31 wd:Q105543609}
    ?tarian wdt:P17 wd:Q252 .
    ?tarian schema:description ?tarianDescription FILTER(LANG(?tarianDescription) = "es") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    for item in data["bindings"]:
        data_dict["desc_es"]= item["count"]["value"]


    query = """SELECT DISTINCT (COUNT(*) AS ?count) WHERE {
    {?tarian wdt:P31 wd:Q107357104}
    UNION
    {?tarian wdt:P31 wd:Q105543609}
    ?tarian wdt:P17 wd:Q252 .
    ?tarian schema:description ?tarianDescription FILTER(LANG(?tarianDescription) = "fr") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    for item in data["bindings"]:
        data_dict["desc_fr"]= item["count"]["value"]

    query = """SELECT DISTINCT (count(DISTINCT ?tarian) as ?count) WHERE {
    {?tarian wdt:P31 wd:Q107357104}
    UNION
    {?tarian wdt:P31 wd:Q105543609}
    ?tarian wdt:P17 wd:Q252 .
    ?tarian skos:altLabel ?AltLabel .
    FILTER(lang(?AltLabel)="id")
    } GROUP BY ?tarianAltLabel"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value    
    for item in data["bindings"]:
        data_dict["aliases_id"]= item["count"]["value"]


    query = """SELECT DISTINCT (count(DISTINCT ?tarian) as ?count) WHERE {
    {?tarian wdt:P31 wd:Q107357104}
    UNION
    {?tarian wdt:P31 wd:Q105543609}
    ?tarian wdt:P17 wd:Q252 .
    ?tarian skos:altLabel ?AltLabel .
    FILTER(lang(?AltLabel)="en")
    } GROUP BY ?tarianAltLabel"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    for item in data["bindings"]:
        data_dict["aliases_en"]= item["count"]["value"]

    
    query = """SELECT DISTINCT (count(DISTINCT ?tarian) as ?count) WHERE {
    {?tarian wdt:P31 wd:Q107357104}
    UNION
    {?tarian wdt:P31 wd:Q105543609}
    ?tarian wdt:P17 wd:Q252 .
    ?tarian skos:altLabel ?AltLabel .
    FILTER(lang(?AltLabel)="es")
    } GROUP BY ?tarianAltLabel"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    for item in data["bindings"]:
        data_dict["aliases_es"]= item["count"]["value"]


    query = """SELECT DISTINCT (count(DISTINCT ?tarian) as ?count) WHERE {
    {?tarian wdt:P31 wd:Q107357104}
    UNION
    {?tarian wdt:P31 wd:Q105543609}
    ?tarian wdt:P17 wd:Q252 .
    ?tarian skos:altLabel ?AltLabel .
    FILTER(lang(?AltLabel)="fr")
    } GROUP BY ?tarianAltLabel"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value    
    for item in data["bindings"]:
        data_dict["aliases_fr"]= item["count"]["value"]
    return json.dumps(data_dict)

@app.route('/bar/weapon', methods=['GET'])
def get_weapon():
    query = """SELECT DISTINCT (COUNT(*) AS ?count) WHERE {
    ?senjata (wdt:P31/(wdt:P279*)) wd:Q728.
    ?senjata wdt:P17 wd:Q252.
    ?senjata rdfs:label ?senjataLabel
    FILTER(LANG(?senjataLabel) = "id") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    data_dict = {}
    for item in data["bindings"]:
        data_dict["label_id"]= item["count"]["value"]

# SENJATA EN
    query = """SELECT DISTINCT (COUNT(*) AS ?count) WHERE {
    ?senjata (wdt:P31/(wdt:P279*)) wd:Q728.
    ?senjata wdt:P17 wd:Q252.
    ?senjata rdfs:label ?senjataLabel
    FILTER(LANG(?senjataLabel) = "en") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    for item in data["bindings"]:
        data_dict["label_en"]= item["count"]["value"]
    
# SENJATA ES
    query = """SELECT DISTINCT (COUNT(*) AS ?count) WHERE {
    ?senjata (wdt:P31/(wdt:P279*)) wd:Q728.
    ?senjata wdt:P17 wd:Q252.
    ?senjata rdfs:label ?senjataLabel
    FILTER(LANG(?senjataLabel) = "es") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    for item in data["bindings"]:
        data_dict["label_es"]= item["count"]["value"]


# SENJATA FR  
    query = """SELECT DISTINCT (COUNT(*) AS ?count) WHERE {
    ?senjata (wdt:P31/(wdt:P279*)) wd:Q728.
    ?senjata wdt:P17 wd:Q252.
    ?senjata rdfs:label ?senjataLabel
    FILTER(LANG(?senjataLabel) = "fr") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    for item in data["bindings"]:
        data_dict["senjata_fr"]= item["count"]["value"]
    
    query = """SELECT DISTINCT (COUNT(*) AS ?count) WHERE {
    ?senjata (wdt:P31/(wdt:P279*)) wd:Q728.
    ?senjata wdt:P17 wd:Q252.
    ?senjata schema:description ?senjataDescription FILTER(LANG(?senjataDescription) = "id") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value    
    for item in data["bindings"]:
        data_dict["desc_id"]= item["count"]["value"]


    query = """SELECT DISTINCT (COUNT(*) AS ?count) WHERE {
    ?senjata (wdt:P31/(wdt:P279*)) wd:Q728.
    ?senjata wdt:P17 wd:Q252.
    ?senjata schema:description ?senjataDescription FILTER(LANG(?senjataDescription) = "en") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    for item in data["bindings"]:
        data_dict["desc_en"]= item["count"]["value"]

    

    query = """SELECT DISTINCT (COUNT(*) AS ?count) WHERE {
    ?senjata (wdt:P31/(wdt:P279*)) wd:Q728.
    ?senjata wdt:P17 wd:Q252.
    ?senjata schema:description ?senjataDescription FILTER(LANG(?senjataDescription) = "es") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    for item in data["bindings"]:
        data_dict["desc_es"]= item["count"]["value"]


    query = """SELECT DISTINCT (COUNT(*) AS ?count) WHERE {
    ?senjata (wdt:P31/(wdt:P279*)) wd:Q728.
    ?senjata wdt:P17 wd:Q252.
    ?senjata schema:description ?senjataDescription FILTER(LANG(?senjataDescription) = "fr") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    for item in data["bindings"]:
        data_dict["desc_fr"]= item["count"]["value"]

    query = """SELECT DISTINCT (count(DISTINCT ?senjata) as ?count) WHERE {
    ?senjata (wdt:P31/(wdt:P279*)) wd:Q728.
    ?senjata wdt:P17 wd:Q252.
    ?senjata skos:altLabel ?AltLabel .
    FILTER(lang(?AltLabel)="id")
    } GROUP BY ?senjataAltLabel"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value    
    for item in data["bindings"]:
        data_dict["aliases_id"]= item["count"]["value"]


    query = """SELECT DISTINCT (count(DISTINCT ?senjata) as ?count) WHERE {
    ?senjata (wdt:P31/(wdt:P279*)) wd:Q728.
    ?senjata wdt:P17 wd:Q252.
    ?senjata skos:altLabel ?AltLabel .
    FILTER(lang(?AltLabel)="en")
    } GROUP BY ?senjataAltLabel"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    for item in data["bindings"]:
        data_dict["aliases_en"]= item["count"]["value"]

    

    query = """SELECT DISTINCT (count(DISTINCT ?senjata) as ?count) WHERE {
    ?senjata (wdt:P31/(wdt:P279*)) wd:Q728.
    ?senjata wdt:P17 wd:Q252.
    ?senjata skos:altLabel ?AltLabel .
    FILTER(lang(?AltLabel)="es")
    } GROUP BY ?senjataAltLabel"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    for item in data["bindings"]:
        data_dict["aliases_es"]= item["count"]["value"]


    query = """SELECT DISTINCT (count(DISTINCT ?senjata) as ?count) WHERE {
    ?senjata (wdt:P31/(wdt:P279*)) wd:Q728.
    ?senjata wdt:P17 wd:Q252.
    ?senjata skos:altLabel ?AltLabel .
    FILTER(lang(?AltLabel)="fr")
    } GROUP BY ?senjataAltLabel"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    for item in data["bindings"]:
        data_dict["aliases_fr"]= item["count"]["value"]
    return json.dumps(data_dict)

@app.route('/bar/song', methods=['GET'])
def get_song():
    query = """SELECT DISTINCT (COUNT(*) AS ?count) WHERE {
    ?lagu wdt:P31 wd:Q105543609.
    ?lagu wdt:P7937 wd:Q7366.
    ?lagu wdt:P17 wd:Q252.
    ?lagu rdfs:label ?laguLabel
    FILTER(LANG(?laguLabel) = "id") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    data_dict = {}
    for item in data["bindings"]:
        data_dict["label_id"]= item["count"]["value"]

# LAGU EN
    query = """SELECT DISTINCT (COUNT(*) AS ?count) WHERE {
    ?lagu wdt:P31 wd:Q105543609.
    ?lagu wdt:P7937 wd:Q7366.
    ?lagu wdt:P17 wd:Q252.
    ?lagu rdfs:label ?laguLabel
    FILTER(LANG(?laguLabel) = "en") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    for item in data["bindings"]:
        data_dict["label_en"]= item["count"]["value"]
    
# LAGU ES
    query = """SELECT DISTINCT (COUNT(*) AS ?count) WHERE {
    ?lagu wdt:P31 wd:Q105543609.
    ?lagu wdt:P7937 wd:Q7366.
    ?lagu wdt:P17 wd:Q252.
    ?lagu rdfs:label ?laguLabel
    FILTER(LANG(?laguLabel) = "es") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    for item in data["bindings"]:
        data_dict["label_es"]= item["count"]["value"]


# LAGU FR  
    query = """SELECT DISTINCT (COUNT(*) AS ?count) WHERE {
    ?lagu wdt:P31 wd:Q105543609.
    ?lagu wdt:P7937 wd:Q7366.
    ?lagu wdt:P17 wd:Q252.
    ?lagu rdfs:label ?laguLabel
    FILTER(LANG(?laguLabel) = "fr") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    for item in data["bindings"]:
        data_dict["label_fr"]= item["count"]["value"]

    query = """SELECT DISTINCT (COUNT(*) AS ?count) WHERE {
    ?lagu wdt:P31 wd:Q105543609.
    ?lagu wdt:P7937 wd:Q7366.
    ?lagu wdt:P17 wd:Q252.
    ?lagu schema:description ?laguDescription FILTER(LANG(?laguDescription) = "id") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value    
    for item in data["bindings"]:
        data_dict["desc_id"]= item["count"]["value"]


    query = """SELECT DISTINCT (COUNT(*) AS ?count) WHERE {
    ?lagu wdt:P31 wd:Q105543609.
    ?lagu wdt:P7937 wd:Q7366.
    ?lagu wdt:P17 wd:Q252.
    ?lagu schema:description ?laguDescription FILTER(LANG(?laguDescription) = "en") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    for item in data["bindings"]:
        data_dict["desc_en"]= item["count"]["value"]

    

    query = """SELECT DISTINCT (COUNT(*) AS ?count) WHERE {
    ?lagu wdt:P31 wd:Q105543609.
    ?lagu wdt:P7937 wd:Q7366.
    ?lagu wdt:P17 wd:Q252.
    ?lagu schema:description ?laguDescription FILTER(LANG(?laguDescription) = "es") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    for item in data["bindings"]:
        data_dict["desc_es"]= item["count"]["value"]


    query = """SELECT DISTINCT (COUNT(*) AS ?count) WHERE {
    ?lagu wdt:P31 wd:Q105543609.
    ?lagu wdt:P7937 wd:Q7366.
    ?lagu wdt:P17 wd:Q252.
    ?lagu schema:description ?laguDescription FILTER(LANG(?laguDescription) = "fr") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    for item in data["bindings"]:
        data_dict["desc_fr"]= item["count"]["value"]

    query = """SELECT DISTINCT (count(DISTINCT ?lagu) as ?count)
    WHERE {
    ?lagu wdt:P31 wd:Q105543609.
    ?lagu wdt:P7937 wd:Q7366.
    ?lagu wdt:P17 wd:Q252.
    ?lagu skos:altLabel ?AltLabel .
    FILTER(lang(?AltLabel)="id")
    } GROUP BY ?laguAltLabel"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value    
    for item in data["bindings"]:
        data_dict["aliases_id"]= item["count"]["value"]


    query = """SELECT DISTINCT (count(DISTINCT ?lagu) as ?count)
    WHERE {
    ?lagu wdt:P31 wd:Q105543609.
    ?lagu wdt:P7937 wd:Q7366.
    ?lagu wdt:P17 wd:Q252.
    ?lagu skos:altLabel ?AltLabel .
    FILTER(lang(?AltLabel)="en")
    } GROUP BY ?laguAltLabel"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    for item in data["bindings"]:
        data_dict["aliases_en"]= item["count"]["value"]

    

    query = """SELECT DISTINCT (count(DISTINCT ?lagu) as ?count)
    WHERE {
    ?lagu wdt:P31 wd:Q105543609.
    ?lagu wdt:P7937 wd:Q7366.
    ?lagu wdt:P17 wd:Q252.
    ?lagu skos:altLabel ?AltLabel .
    FILTER(lang(?AltLabel)="es")
    } GROUP BY ?laguAltLabel"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    for item in data["bindings"]:
        data_dict["aliases_es"]= item["count"]["value"]


    query = """SELECT DISTINCT (count(DISTINCT ?lagu) as ?count)
    WHERE {
    ?lagu wdt:P31 wd:Q105543609.
    ?lagu wdt:P7937 wd:Q7366.
    ?lagu wdt:P17 wd:Q252.
    ?lagu skos:altLabel ?AltLabel .
    FILTER(lang(?AltLabel)="fr")
    } GROUP BY ?laguAltLabel"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    for item in data["bindings"]:
        data_dict["aliases_fr"]= item["count"]["value"]
    return json.dumps(data_dict)



# RUMAH LABEL (ID, EN, ES, FR)

# RUMAH ID
@app.route('/bar/house')
def get_house():
    query = """SELECT DISTINCT (COUNT(*) AS ?count)
    WHERE {
    ?rumah wdt:P31 wd:Q7419654.
    ?rumah wdt:P17 wd:Q252.
    ?rumah rdfs:label ?rumahLabel
    FILTER(LANG(?rumahLabel) = "id") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    data_dict = {}
    for item in data["bindings"]:
        data_dict["label_id"]= item["count"]["value"]

# RUMAH EN
    query = """SELECT DISTINCT (COUNT(*) AS ?count)
    WHERE {
    ?rumah wdt:P31 wd:Q7419654.
    ?rumah wdt:P17 wd:Q252.
    ?rumah rdfs:label ?rumahLabel
    FILTER(LANG(?rumahLabel) = "en") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    for item in data["bindings"]:
        data_dict["label_en"]= item["count"]["value"]
    
# RUMAH ES
    query = """SELECT DISTINCT (COUNT(*) AS ?count)
    WHERE {
    ?rumah wdt:P31 wd:Q7419654.
    ?rumah wdt:P17 wd:Q252.
    ?rumah rdfs:label ?rumahLabel
    FILTER(LANG(?rumahLabel) = "es") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    for item in data["bindings"]:
        data_dict["label_es"]= item["count"]["value"]


# RUMAH FR  
    query = """SELECT DISTINCT (COUNT(*) AS ?count)
    WHERE {
    ?rumah wdt:P31 wd:Q7419654.
    ?rumah wdt:P17 wd:Q252.
    ?rumah rdfs:label ?rumahLabel
    FILTER(LANG(?rumahLabel) = "fr") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    for item in data["bindings"]:
        data_dict["label_fr"]= item["count"]["value"]
    



# RUMAH DESKRIPSI (ID, EN, ES, FR)

    query = """SELECT DISTINCT (COUNT(*) AS ?count)
    WHERE {
    ?rumah wdt:P31 wd:Q7419654.
    ?rumah wdt:P17 wd:Q252.
    ?rumah schema:description ?rumahDescription FILTER(LANG(?rumahDescription) = "id") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    for item in data["bindings"]:
        data_dict["desc_id"]= item["count"]["value"]


    query = """SELECT DISTINCT (COUNT(*) AS ?count)
    WHERE {
    ?rumah wdt:P31 wd:Q7419654.
    ?rumah wdt:P17 wd:Q252.
    ?rumah schema:description ?rumahDescription FILTER(LANG(?rumahDescription) = "en") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    for item in data["bindings"]:
        data_dict["desc_en"]= item["count"]["value"]

    

    query = """SELECT DISTINCT (COUNT(*) AS ?count)
    WHERE {
    ?rumah wdt:P31 wd:Q7419654.
    ?rumah wdt:P17 wd:Q252.
    ?rumah schema:description ?rumahDescription FILTER(LANG(?rumahDescription) = "es") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    for item in data["bindings"]:
        data_dict["desc_es"]= item["count"]["value"]


    query = """SELECT DISTINCT (COUNT(*) AS ?count)
    WHERE {
   ?rumah wdt:P31 wd:Q7419654.
    ?rumah wdt:P17 wd:Q252.
    ?rumah schema:description ?rumahDescription FILTER(LANG(?rumahDescription) = "fr") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    for item in data["bindings"]:
        data_dict["desc_fr"]= item["count"]["value"]




# RUMAH ALIASES (ID, EN, ES, FR)
    query = """SELECT DISTINCT (count(DISTINCT ?rumah) as ?count)
    WHERE {
    ?rumah wdt:P31 wd:Q7419654.
    ?rumah wdt:P17 wd:Q252.
    ?rumah skos:altLabel ?AltLabel . FILTER(lang(?AltLabel)="id")
    } GROUP BY ?rumahAltLabel"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    for item in data["bindings"]:
        data_dict["aliases_id"]= item["count"]["value"]


    query = """SELECT DISTINCT (count(DISTINCT ?rumah) as ?count)
    WHERE {
    ?rumah wdt:P31 wd:Q7419654.
    ?rumah wdt:P17 wd:Q252.
    ?rumah skos:altLabel ?AltLabel . FILTER(lang(?AltLabel)="en")
    } GROUP BY ?rumahAltLabel"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    for item in data["bindings"]:
        data_dict["aliases_en"]= item["count"]["value"]

    

    query = """SELECT DISTINCT (count(DISTINCT ?rumah) as ?count)
    WHERE {
    ?rumah wdt:P31 wd:Q7419654.
    ?rumah wdt:P17 wd:Q252.
    ?rumah skos:altLabel ?AltLabel . FILTER(lang(?AltLabel)="es")
    } GROUP BY ?rumahAltLabel"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    for item in data["bindings"]:
        data_dict["aliases_es"]= item["count"]["value"]


    query = """SELECT DISTINCT (count(DISTINCT ?rumah) as ?count)
    WHERE {
    ?rumah wdt:P31 wd:Q7419654.
    ?rumah wdt:P17 wd:Q252.
    ?rumah skos:altLabel ?AltLabel . FILTER(lang(?AltLabel)="fr")
    } GROUP BY ?rumahAltLabel"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    for item in data["bindings"]:
        data_dict["aliases_fr"]= item["count"]["value"]
    return json.dumps(data_dict)




# UPACARA ADAT LABEL (ID, EN, ES, FR)

#UPACARA ADAT ID
@app.route('/bar/ceremony')
def get_ceremony():
    query = """SELECT DISTINCT (COUNT(*) AS ?count) WHERE {
    ?upacara wdt:P31 wd:Q189819.
    ?upacara wdt:P17 wd:Q252.
    ?upacara rdfs:label ?upacaraLabel
    FILTER(LANG(?upacaraLabel) = "id") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    data_dict = {}
    for item in data["bindings"]:
        data_dict["label_id"]= item["count"]["value"]

# UPACARA EN
    query = """SELECT DISTINCT (COUNT(*) AS ?count) WHERE {
    ?upacara wdt:P31 wd:Q189819.
    ?upacara wdt:P17 wd:Q252.
    ?upacara rdfs:label ?upacaraLabel
    FILTER(LANG(?upacaraLabel) = "en") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    for item in data["bindings"]:
        data_dict["label_en"]= item["count"]["value"]
    
# UPACARA ES
    query = """SELECT DISTINCT (COUNT(*) AS ?count) WHERE {
    ?upacara wdt:P31 wd:Q189819.
    ?upacara wdt:P17 wd:Q252.
    ?upacara rdfs:label ?upacaraLabel
    FILTER(LANG(?upacaraLabel) = "es") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    for item in data["bindings"]:
        data_dict["label_es"]= item["count"]["value"]


# UPACARA FR  
    query = """SELECT DISTINCT (COUNT(*) AS ?count) WHERE {
    ?upacara wdt:P31 wd:Q189819.
    ?upacara wdt:P17 wd:Q252.
    ?upacara rdfs:label ?upacaraLabel
    FILTER(LANG(?upacaraLabel) = "fr") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    for item in data["bindings"]:
        data_dict["label_fr"]= item["count"]["value"]




# UPACARA DESKRIPSI (ID, EN, ES, FR)

    query = """SELECT DISTINCT (COUNT(*) AS ?count) WHERE {
    ?upacara wdt:P31 wd:Q189819.
    ?upacara wdt:P17 wd:Q252.
    ?upacara schema:description ?upacaraDescription FILTER(LANG(?upacaraDescription) = "id") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    for item in data["bindings"]:
        data_dict["desc_id"]= item["count"]["value"]


    query = """SELECT DISTINCT (COUNT(*) AS ?count) WHERE {
    ?upacara wdt:P31 wd:Q189819.
    ?upacara wdt:P17 wd:Q252.
    ?upacara schema:description ?upacaraDescription FILTER(LANG(?upacaraDescription) = "en") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    for item in data["bindings"]:
        data_dict["desc_en"]= item["count"]["value"]

    

    query = """SELECT DISTINCT (COUNT(*) AS ?count) WHERE {
    ?upacara wdt:P31 wd:Q189819.
    ?upacara wdt:P17 wd:Q252.
    ?upacara schema:description ?upacaraDescription FILTER(LANG(?upacaraDescription) = "es") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    for item in data["bindings"]:
        data_dict["desc_es"]= item["count"]["value"]


    query = """SELECT DISTINCT (COUNT(*) AS ?count) WHERE {
    ?upacara wdt:P31 wd:Q189819.
    ?upacara wdt:P17 wd:Q252.
    ?upacara schema:description ?upacaraDescription FILTER(LANG(?upacaraDescription) = "fr") .
    }"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    for item in data["bindings"]:
        data_dict["desc_fr"]= item["count"]["value"]



# UPACARA ALIASES (ID, EN, ES, FR)

    query = """SELECT DISTINCT (count(DISTINCT ?upacara) as ?count)
    WHERE {
    ?upacara wdt:P31 wd:Q189819.
    ?upacara wdt:P17 wd:Q252.
    ?upacara skos:altLabel ?AltLabel .
    FILTER(lang(?AltLabel)="id")
    } GROUP BY ?upacaraAltLabel"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    for item in data["bindings"]:
        data_dict["aliases_id"]= item["count"]["value"]


    query = """SELECT DISTINCT (count(DISTINCT ?upacara) as ?count) 
    WHERE {
    ?upacara wdt:P31 wd:Q189819.
    ?upacara wdt:P17 wd:Q252.
    ?upacara skos:altLabel ?AltLabel .
    FILTER(lang(?AltLabel)="en")
    } GROUP BY ?upacaraAltLabel"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    for item in data["bindings"]:
        data_dict["aliases_en"]= item["count"]["value"]

    

    query = """SELECT DISTINCT (count(DISTINCT ?upacara) as ?count) 
    WHERE {
    ?upacara wdt:P31 wd:Q189819.
    ?upacara wdt:P17 wd:Q252.
    ?upacara skos:altLabel ?AltLabel .
    FILTER(lang(?AltLabel)="es")
    } GROUP BY ?upacaraAltLabel"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    for item in data["bindings"]:
        data_dict["aliases_es"]= item["count"]["value"]


    query = """SELECT DISTINCT (count(DISTINCT ?upacara) as ?count) 
    WHERE {
    ?upacara wdt:P31 wd:Q189819.
    ?upacara wdt:P17 wd:Q252.
    ?upacara skos:altLabel ?AltLabel .
    FILTER(lang(?AltLabel)="fr")
    } GROUP BY ?upacaraAltLabel"""
    user_agent = "WDQS-example Python/%s.%s" % (sys.version_info[0], sys.version_info[1])
    # TODO adjust user agent; see https://w.wiki/CX6
    sparql = SPARQLWrapper(endpoint_url, agent=user_agent)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    data = sparql.query().convert()["results"]
    # create dictionary with id and value
    for item in data["bindings"]:
        data_dict["aliases_fr"]= item["count"]["value"]
    return json.dumps(data_dict)

app.run(host='0.0.0.0',port='8080')