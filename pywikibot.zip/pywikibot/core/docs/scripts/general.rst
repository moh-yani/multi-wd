General pages changes scripts
=============================

archivebot script description description
-----------------------------------------

.. automodule:: scripts.archivebot
   :no-members:

movepages script description description
----------------------------------------

.. automodule:: scripts.movepages
   :no-members:

pagefromfile script description description
-------------------------------------------

.. automodule:: scripts.pagefromfile
   :no-members:
