Utility scripts
===============

cache script description
------------------------

.. automodule:: scripts.maintenance.cache
   :no-members:

colors script description
-------------------------

.. automodule:: scripts.maintenance.colors
   :no-members:

preload_sites script description
--------------------------------

.. automodule:: scripts.maintenance.preload_sites
   :no-members:

sorting\_order script description
---------------------------------

.. automodule:: scripts.maintenance.sorting_order
   :no-members:

update\_linktrails script description
-------------------------------------

.. automodule:: scripts.maintenance.update_linktrails
   :no-members:

wikimedia\_sites script description
-----------------------------------

.. automodule:: scripts.maintenance.wikimedia_sites
   :no-members:

