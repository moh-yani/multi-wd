Unsorted scripts
================

basic script description
------------------------

.. automodule:: scripts.basic
   :no-members:

change\_pagelang script description
-----------------------------------

.. automodule:: scripts.change_pagelang
   :no-members:

coordinate\_import script description
-------------------------------------

.. automodule:: scripts.coordinate_import
   :no-members:

delinker script description
---------------------------
.. automodule:: scripts.delinker
   :no-members:

djvutext script description
---------------------------
.. automodule:: scripts.djvutext
   :no-members:

download\_dump script description
---------------------------------

.. automodule:: scripts.download_dump
   :no-members:

fixing\_redirects script description
------------------------------------

.. automodule:: scripts.fixing_redirects
   :no-members:

misspelling script description
------------------------------

.. automodule:: scripts.misspelling
   :no-members:

noreferences script description
-------------------------------

.. automodule:: scripts.noreferences
   :no-members:


parser\_function\_count script description
------------------------------------------

.. automodule:: scripts.parser_function_count
   :no-members:


reflinks script description
---------------------------

.. automodule:: scripts.reflinks
   :no-members:

replicate\_wiki script description
----------------------------------

.. automodule:: scripts.replicate_wiki
   :no-members:


watchlist script description
----------------------------

.. automodule:: scripts.watchlist
   :no-members:
