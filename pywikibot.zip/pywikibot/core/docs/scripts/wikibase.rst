Wikibase scripts
================

claimit script description
--------------------------

.. automodule:: scripts.claimit
   :no-members:

dataextend script description
-----------------------------

.. automodule:: scripts.dataextend
   :no-members:

harvest\_template script description
------------------------------------

.. automodule:: scripts.harvest_template
   :no-members:

illustrate\_wikidata script description
---------------------------------------

.. automodule:: scripts.illustrate_wikidata
   :no-members:

interwikidata script description
--------------------------------

.. automodule:: scripts.interwikidata
   :no-members:

newitem script description
--------------------------

.. automodule:: scripts.newitem
   :no-members:
