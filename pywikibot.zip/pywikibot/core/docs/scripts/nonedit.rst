Non editing scripts
===================

listpages script description
----------------------------

.. automodule:: scripts.listpages
   :no-members:

touch script description
------------------------

.. automodule:: scripts.touch
   :no-members:
