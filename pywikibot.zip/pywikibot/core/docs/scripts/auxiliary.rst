Auxiliary scripts
=================

clean\_sandbox script description
---------------------------------

.. automodule:: scripts.clean_sandbox
   :no-members:

cosmetic\_changes script description
------------------------------------

.. automodule:: scripts.cosmetic_changes
   :no-members:

transferbot script description
------------------------------

.. automodule:: scripts.transferbot
   :no-members:
