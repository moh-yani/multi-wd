Administrative scripts
======================

blockpageschecker script description
------------------------------------

.. automodule:: scripts.blockpageschecker
   :no-members:

delete script description
-------------------------

.. automodule:: scripts.delete
   :no-members:

patrol script description
-------------------------

.. automodule:: scripts.patrol
   :no-members:

protect script description
--------------------------

.. automodule:: scripts.protect
   :no-members:

revertbot script description
----------------------------

.. automodule:: scripts.revertbot
   :no-members:

speedy\_delete script description
---------------------------------

.. automodule:: scripts.speedy_delete
   :no-members:
