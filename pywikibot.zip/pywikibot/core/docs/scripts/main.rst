Main bot scripts
================

add\_text script description
----------------------------

.. automodule:: scripts.add_text
   :no-members:

category script description
---------------------------

.. automodule:: scripts.category
   :no-members:

replace script description
--------------------------

.. automodule:: scripts.replace
   :no-members:

solve\_disambiguation script description
----------------------------------------

.. automodule:: scripts.solve_disambiguation
   :no-members:

upload script description
-------------------------

.. automodule:: scripts.upload
   :no-members:

weblinkchecker script description
---------------------------------

.. automodule:: scripts.weblinkchecker
   :no-members:
