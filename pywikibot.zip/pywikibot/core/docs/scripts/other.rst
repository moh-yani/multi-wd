Other bot scripts
=================

welcome script description
--------------------------

.. automodule:: scripts.welcome
   :no-members:
