Global bot scripts
==================

interwiki script description
----------------------------

Creates or modifies Interlanguage links between projects.

.. automodule:: scripts.interwiki
   :no-members:


redirect script description
---------------------------

.. automodule:: scripts.redirect
   :no-members:
