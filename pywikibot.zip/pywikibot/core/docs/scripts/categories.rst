Categories scripts
==================

category\_redirect script description
-------------------------------------

.. automodule:: scripts.category_redirect
   :no-members:

commonscat script description
-----------------------------

.. automodule:: scripts.commonscat
   :no-members:

