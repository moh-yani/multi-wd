scripts.maintenance utility scripts
===================================

.. automodule:: scripts.maintenance

Submodules
----------

scripts.maintenance.cache script
--------------------------------

.. automodule:: scripts.maintenance.cache
   :ignore-module-all:

scripts.maintenance.colors script
---------------------------------

.. automodule:: scripts.maintenance.colors

scripts.maintenance.make\_i18n\_dict script
-------------------------------------------

.. automodule:: scripts.maintenance.make_i18n_dict

scripts.maintenance.preload_sites script
-----------------------------------------

.. automodule:: scripts.maintenance.preload_sites

scripts.maintenance.sorting\_order script
-----------------------------------------

.. automodule:: scripts.maintenance.sorting_order

scripts.maintenance.update\_linktrails script
---------------------------------------------

.. automodule:: scripts.maintenance.update_linktrails

scripts.maintenance.wikimedia\_sites script
-------------------------------------------

.. automodule:: scripts.maintenance.wikimedia_sites

