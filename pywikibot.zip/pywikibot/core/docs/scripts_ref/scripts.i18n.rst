scripts.i18n translation files
==============================

.. automodule:: scripts.i18n