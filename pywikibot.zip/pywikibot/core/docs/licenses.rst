:tocdepth: 1

Licenses
========

**The framework itself and this documentation** are available under the
:ref:`MIT license`; manual pages on mediawiki.org are
available under the `CC-BY-SA 3.0`_ license. The Pywikibot logo is
available under the `CC-BY-SA 4.0`_ license.


MIT License
-----------
**The framework is available under the MIT license.**

.. include:: ../LICENSE


.. _CC-BY-SA 3.0: https://creativecommons.org/licenses/by-sa/3.0/
.. _CC-BY-SA 4.0: https://creativecommons.org/licenses/by-sa/4.0/
