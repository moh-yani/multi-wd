pywikibot.data package
======================

.. automodule:: pywikibot.data

Submodules
----------

pywikibot.data.api module
-------------------------

.. automodule:: pywikibot.data.api

pywikibot.data.mysql module
---------------------------

.. automodule:: pywikibot.data.mysql

pywikibot.data.sparql module
----------------------------

.. automodule:: pywikibot.data.sparql

pywikibot.data.wikistats module
-------------------------------

.. automodule:: pywikibot.data.wikistats


