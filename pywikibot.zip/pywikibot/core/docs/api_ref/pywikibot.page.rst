pywikibot.page package
=======================

.. automodule:: pywikibot.page

Submodules
----------

pywikibot.page.\_collections module
-----------------------------------

.. automodule:: pywikibot.page._collections

pywikibot.page.\_decorators module
----------------------------------

.. automodule:: pywikibot.page._decorators

pywikibot.page.\_revision module
--------------------------------

.. automodule:: pywikibot.page._revision
