specialbots package
===================

.. automodule:: pywikibot.specialbots
