userinterfaces package
======================

.. automodule:: pywikibot.userinterfaces

\_interface\_base module
------------------------

.. automodule:: pywikibot.userinterfaces._interface_base

terminal\_interface module
--------------------------

.. automodule:: pywikibot.userinterfaces.terminal_interface

terminal\_interface\_base module
--------------------------------

.. automodule:: pywikibot.userinterfaces.terminal_interface_base

terminal\_interface\_unix module
--------------------------------

.. automodule:: pywikibot.userinterfaces.terminal_interface_unix

terminal\_interface\_win32 module
---------------------------------

.. automodule:: pywikibot.userinterfaces.terminal_interface_win32

buffer\_interface module
------------------------

.. automodule:: pywikibot.userinterfaces.buffer_interface

gui module
----------

.. automodule:: pywikibot.userinterfaces.gui

transliteration module
----------------------

.. automodule:: pywikibot.userinterfaces.transliteration

win32\_unicode module
---------------------

.. automodule:: pywikibot.userinterfaces.win32_unicode


