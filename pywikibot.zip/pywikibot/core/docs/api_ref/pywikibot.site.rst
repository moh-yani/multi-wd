pywikibot.site package
=======================

.. automodule:: pywikibot.site
   :no-members:

BaseSite package
----------------
.. automodule:: pywikibot.site._basesite

APISite Package
---------------
.. automodule:: pywikibot.site._apisite

.. automodule:: pywikibot.site._extensions

.. automodule:: pywikibot.site._generators

DataSite Package
----------------
.. automodule:: pywikibot.site._datasite

Obsolete Sites Package
----------------------
.. automodule:: pywikibot.site._obsoletesites

Siteinfo Package
----------------
.. automodule:: pywikibot.site._siteinfo

Namespace Package
-----------------
.. automodule:: pywikibot.site._namespace

TokenWallet Package
-------------------
.. automodule:: pywikibot.site._tokenwallet

Uploader Package
----------------
.. automodule:: pywikibot.site._upload

