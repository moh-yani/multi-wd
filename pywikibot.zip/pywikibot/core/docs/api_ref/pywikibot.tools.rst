tools package
=============

.. automodule:: pywikibot.tools

tools.chars module
------------------

.. automodule:: pywikibot.tools.chars

tools.deprecate module
----------------------

.. automodule:: pywikibot.tools._deprecate

tools.djvu module
-----------------

.. automodule:: pywikibot.tools.djvu

tools.formatter module
----------------------

.. automodule:: pywikibot.tools.formatter

tools.\_logging module
----------------------

.. automodule:: pywikibot.tools._logging
