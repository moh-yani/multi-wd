Utility scripts
===============

.. automodule:: pywikibot.scripts
   :no-members:

pwb wrapper script
------------------

.. automodule:: pwb
   :no-members:

generate\_family\_file script
-----------------------------

.. automodule:: pywikibot.scripts.generate_family_file
   :no-members:

generate\_user\_files script
----------------------------

.. automodule:: pywikibot.scripts.generate_user_files
   :no-members:

shell script
------------

.. automodule:: pywikibot.scripts.shell
   :no-members:

version script
--------------

.. automodule:: pywikibot.scripts.version
   :no-members:
