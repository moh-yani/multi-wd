Utility scripts
===============

.. automodule:: pywikibot.scripts
   :private-members:

pwb wrapper script
------------------

.. automodule:: pwb

generate\_family\_file script
-----------------------------

.. automodule:: pywikibot.scripts.generate_family_file

generate\_user\_files script
----------------------------

.. automodule:: pywikibot.scripts.generate_user_files

shell script
------------

.. automodule:: pywikibot.scripts.shell

version script
--------------

.. automodule:: pywikibot.scripts.version
