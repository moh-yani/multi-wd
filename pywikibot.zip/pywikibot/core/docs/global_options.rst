Global Options
--------------

Global arguments available for all bots:

.. literalinclude:: ../pywikibot/bot.py
   :language: console
   :start-after: (Global arguments available for all bots)
   :end-before: """