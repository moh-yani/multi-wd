"""Module providing several layers of data access to the wiki."""
