"""Communication layer."""
