#Edit / menambahkan label, deskripsi, dan alias
import pywikibot

site = pywikibot.Site("wikidata", "wikidata")
repo = site.data_repository()
item = pywikibot.ItemPage(repo, "Q12516004") #Mengambil QID dari Soto Betawi


new_labels = {"id": "Soto Betawi", "en": "Soto Betawi", "fr": "Soto Betawi", "es": "Soto Betawi"}
new_descr = {"id": "makanan soto dari Jakarta", "en": "Indonesian food", "fr": "nourriture d'indonésie", "es": "comida de indonesia"}
new_alias = {"id": ["soto betawi"], "en": ["soto betawi"], "fr": ["soto betawi"], "es": ["soto betawi"]}


item.editLabels(labels=new_labels, summary="Setting new labels.")
item.editDescriptions(new_descr, summary="Setting new descriptions.")
item.editAliases(new_alias, summary="Setting new aliases.")